# Change Log #

See [Releases](https://github.com/novoda/bintray-release/releases) for all versions and change log.