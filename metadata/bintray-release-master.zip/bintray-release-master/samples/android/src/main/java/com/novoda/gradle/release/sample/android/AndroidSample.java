package com.novoda.gradle.release.sample.android;

public class AndroidSample {

    public static void hello() {
        System.out.println("Hello world from AndroidSample");
    }

}
