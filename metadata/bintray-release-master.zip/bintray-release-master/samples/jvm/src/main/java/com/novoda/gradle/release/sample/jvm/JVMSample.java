package com.novoda.gradle.release.sample.jvm;

public class JVMSample {

    public static void hello() {
        System.out.println("Hello world from JVMSample");
    }

}
