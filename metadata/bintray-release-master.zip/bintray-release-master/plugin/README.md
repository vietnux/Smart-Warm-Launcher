This is the module for the source code of the `bintray-release` plugin.

The entry point for this code is the [ReleasePlugin.groovy](core/src/main/groovy/com/novoda/gradle/release/ReleasePlugin.groovy) class. 
If this is your first time, you'll probably want to start there.

If you want to test your code changes you make here, see the [samples module](../samples/)
