## CHANGELOG:

#### 0.0.5
- Reimplemented blocking swipes on slides
- Reimplemented last slide alpha exit transition effect

#### 0.0.4
- Added support for showing snackbars
- Added support for asking permissions in custom slides
- Fix: canMoveFurther() method works on last slide
- Fix: Library isn't crashing when no slides provided

#### 0.0.3
- Added onFinish method

#### 0.0.2
- Added API for animations
- Added Travis config file
- Added Splash Screen for example app
- Bug fixes

#### 0.0.1
- Initial commit with library
