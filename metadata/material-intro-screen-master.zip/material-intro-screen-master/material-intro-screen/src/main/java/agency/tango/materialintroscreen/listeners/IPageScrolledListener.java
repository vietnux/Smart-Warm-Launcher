package agency.tango.materialintroscreen.listeners;

public interface IPageScrolledListener {
    void pageScrolled(int position, float offset);
}