package agency.tango.materialintroscreen.listeners;

public interface IFinishListener {
    void doOnFinish();
}
