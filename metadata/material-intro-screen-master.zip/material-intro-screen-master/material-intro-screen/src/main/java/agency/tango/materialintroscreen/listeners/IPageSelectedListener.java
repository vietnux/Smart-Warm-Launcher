package agency.tango.materialintroscreen.listeners;

public interface IPageSelectedListener {
    void pageSelected(int position);
}