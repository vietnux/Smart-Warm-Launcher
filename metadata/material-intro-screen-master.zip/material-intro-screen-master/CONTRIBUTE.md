## Contribute
Feel free to contribute code to Material Intro Screen. You can do it by forking the repository via Github and sending pull request with changes.

When submitting code, please make every effort to follow existing conventions and style in order to keep the code as readable as possible. Also be sure that all tests are passing. 
